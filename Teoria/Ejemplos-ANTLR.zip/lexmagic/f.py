# a test
f(1, # first arg

  2, # second arg
     # blank line with a comment
  3) # third arg
g() # on end

1+\
2+\
3
